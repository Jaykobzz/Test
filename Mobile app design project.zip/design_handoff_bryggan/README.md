# Handoff: FRIEND – visuell riktning "Bryggan" (1b)

## Översikt
Ny visuell nivå för FRIEND-appen (Expo/React Native, repo `Jaykobzz/Test`, branch `claude/repo-assessment-h6zbod`, mappen `mobile/`). Vald riktning: **1b "Bryggan"** — djup gran + bränd orange, typsnitt **Unbounded** (display) + **Hanken Grotesk** (UI/brödtext). Leveransen omfattar tokens, komponentstilar, sex skärmlayouter och ett eget ikonset som ersätter emojin för aktiviteter.

## Om designfilerna
Filerna i paketet är **designreferenser skapade i HTML** — prototyper som visar avsett utseende, inte produktionskod att kopiera. Uppgiften är att applicera designen i den **befintliga Expo/React Native-kodbasen** med dess etablerade mönster: uppdatera `mobile/src/theme.ts` med tokens nedan, ladda typsnitten, lägg in ikonsetet och styla om befintliga skärmar och komponenter. Bygg inget nytt ramverk och byt inte navigationslösning — expo-router-strukturen står kvar.

Öppna filerna i en webbläsare:
- `FRIEND Designsystem.dc.html` — tokens och typografi. **Titta bara på kortet märkt 1b**; 1a och 1c är bortvalda alternativ.
- `FRIEND Mockup.dc.html` — sex skärmar i iOS-ram, id 2a–2f.
- `FRIEND Ikoner.dc.html` — hela ikonarket med slugs, storlekar och före/efter.

## Fidelity
**Hifi.** Färger, typografi, radier, skuggor och komponentstilar är exakta och ska följas till punkt och pricka. Skärmlayouterna (2a–2f) är hifi vad gäller struktur, hierarki och spacing, men de är ritade i CSS på en 402 × 874-yta — översätt måtten till React Native-motsvarigheter snarare än att jaga pixlar. Informationshierarkin i mockupen speglar befintliga skärmar; ingen ny funktionalitet är påhittad.

## Typsnitt
Bundla via Expo Google Fonts: `@expo-google-fonts/unbounded` och `@expo-google-fonts/hanken-grotesk`.
- **Unbounded** 600, 700 — endast rubriker/display och logotypen
- **Hanken Grotesk** 400, 600, 700 — allt annat (UI, brödtext, knappar, etiketter)

Ladda i root-layouten med `useFonts` och håll splash uppe till dess `fontsLoaded`. Ingen text ska falla tillbaka på systemfont i produktionsbygget.

## Design tokens

### Färger — ljust läge
| Roll | Hex |
|---|---|
| bakgrund | `#F7F5EF` |
| yta | `#FFFFFF` |
| yta-alt | `#EEEAE0` |
| kant | `#DFD9CB` |
| text | `#14201B` |
| text-dämpad | `#56635C` |
| text-svag | `#83908A` |
| primär | `#15604B` |
| primär-mjuk | `#D9EBE2` (text på mjuk: `#0D4A39`) |
| på-primär | `#FFFFFF` |
| accent | `#B3541E` |
| stjärna | `#E3A81C` |
| varning | `#B3261E` (mjuk bakgrund `#F7E0DA`) |
| overlay-pill | `rgba(12,14,18,.72)` med vit text |

### Färger — mörkt läge
| Roll | Hex |
|---|---|
| bakgrund | `#0F1613` |
| yta | `#182019` |
| yta-alt | `#212B23` |
| kant | `#2C382F` |
| text | `#EDF2EC` |
| text-dämpad | `#A7B4A9` |
| text-svag | `#75837A` |
| primär | `#5FBF9E` |
| primär-mjuk | `#143528` |
| på-primär | `#06251A` |
| accent | `#E89A66` |
| stjärna | `#E8B84E` |
| varning | `#F08C7D` |

Accenten är avsiktligt sparsam — max en förekomst per skärm (t.ex. veckoräknaren på profilen, notisprick i flikfältet).

### Typografiskala
| Roll | Typsnitt | Storlek/radavstånd |
|---|---|---|
| display | Unbounded 600 | 24 / 32 |
| titel | Unbounded 600 | 18 / 24 |
| rubrik | Unbounded 600 | 14 / 20 |
| brödtext | Hanken Grotesk 400 | 15 / 22 |
| liten | Hanken Grotesk 400 | 13 / 18 |
| mikro/etikett | Hanken Grotesk 700 | 11 / 15, letter-spacing 0.06em, VERSALER |
| knapptext | Hanken Grotesk 700 | 15 |
| logotyp "FRIEND" | Unbounded 700 | 16, letter-spacing 0.02em |

### Spacing
Steg om 4: **4, 8, 10, 12, 14, 16, 18, 20, 26, 34**. Skärmarnas sidmarginal är **20**. Vertikalt mellan sektioner **14–18**. Kortens innerpadding **14–16**.

### Radier & skuggor
- Knappar, chips, badges, avatarer: helrunda (`borderRadius: 999`)
- Kort: **18**. Fält och listgrupper: **14**. Bottensheet/innehållsyta som lyfter över foto: **22** upptill.
- Chattbubbla: **14**, egen bubbla `14 14 4 14` (spetsigt nedre hörn mot avsändaren)
- Kortskugga ljust läge: `0 6px 14px rgba(20,32,27,.07)` + 1 px kant `#DFD9CB`. I React Native: `shadowColor:'#14201B', shadowOpacity:.07, shadowRadius:14, shadowOffset:{width:0,height:6}, elevation:3`.
- Mörkt läge har **ingen** skugga — bara kant `#2C382F`.

## Komponenter
- **Primärknapp** — bg primär, text på-primär, Hanken 700 15, padding 15 × 24, helrund. Full bredd i fasta bottenfält.
- **Sekundärknapp** — bg yta, 1 px kant, text `#14201B`, samma mått.
- **Textknapp** — text primär, ingen yta.
- **Destruktiv** — text `#B3261E` utan yta (t.ex. "Anmäl någon"); med yta `#F7E0DA` när den behöver vikt.
- **Chip** — padding 9 × 15, gap ikon→etikett 6. Vald: bg primär + vit text + Hanken 700. Oval: bg yta-alt + text dämpad + 600. Info: bg primär-mjuk + text `#0D4A39`.
- **Aktivitetskort** — yta, radie 18, kortskugga. Omslagsfoto 150 högt överst; "Du är med"-pill (primär) uppe vänster, distanspill (overlay-pill) uppe höger. Under: titel i titel-stilen, metarad (tid · plats) i liten/dämpad, sedan värd-rad — avatar 28 (bg primär-mjuk, initial `#0D4A39`), namn 600 13, ★ stjärna + betyg — och "N platser kvar" som info-pill till höger.
- **Avatarer** — 28 i kortrad, 40 i listrad, 46 i deltagarrutnät, 76 på profil. Initial i Hanken 700, bg yta-alt/primär-mjuk.
- **Fält** — yta med 1 px kant, radie 14, padding 14 × 16, text 16. Aktivt fält: kant **primär**.
- **Listgrupp** — yta, radie 18, rader delade av 1 px `#EEEAE0`, aldrig kant mellan sista raden och kortkanten.
- **Toggle** — 50 × 30, knopp 24, av: bg yta-alt, på: bg primär.
- **Flikfält** — yta med 88 % opacitet, 1 px topkant, ikon 22 + etikett 10,5. Aktiv flik: primär och etikett i 700. Inaktiv: `#83908A` och 600. Notisprick 9 px i accent med 2 px yta-färgad ring.
- **Chattbubblor** — andras: yta + 1 px kant, tidsstämpel i text-svag under texten. Egen: primär bg (mörkt läge `#5FBF9E`) med på-primär text, tid + "Läst" högerställt i 60 % opacitet. Systemhändelse ("SARA HAKADE PÅ 🎉"): centrerad mikrotext i text-svag, ingen bubbla. Skrivindikator: tre 6 px punkter i fallande opacitet i en bubbla.

## Skärmar

### 2a Upptäck (`app/(tabs)/index.tsx`)
Toppfält med logotyp och profilavatar, sedan display-rubrik "Upptäck" med platsrad (pin-ikon + "Skarpnäck · inom 5 km"). Horisontell filterrad: "Allt" vald + en chip per intresse med ikon. Vertikal lista av aktivitetskort, gap 14. Flikfält nederst.

### 2b Aktivitetsdetalj (`app/aktivitet/[id].tsx`)
Omslagsfoto 280 högt, tillbakaknapp 38 i halvtransparent vit cirkel uppe vänster, distanspill uppe höger. Innehållsytan lyfter −22 över fotot med radie 22 upptill. Kategori-chip, display-titel, två metarader med ikon (tid, plats), beskrivning i brödtext, värdkort (avatar 44, namn, ★ + antal aktiviteter, "Profil"-knapp), sedan "VILL HAKA PÅ (3)" med avatarrutnät 46 + förnamn. Fast bottenfält: primärknapp "Jag vill haka på" + 52 px hjärt-knapp.

### 2c Skapa aktivitet (`app/aktivitet/ny.tsx`)
Modal-toppfält: "Avbryt" / titel / "Lägg upp" (avstängd i text-svag till dess formuläret är giltigt). Fyra grupper: fritextfält för vad (aktivt = primär kant), kategorichips, listgrupp med När / Var / Antal platser (stepper: 32 px minus i yta-alt, tal i Unbounded 600 17, plus i primär-mjuk), och omslagsfoto som streckad 120 px yta (valfritt). Infoyta i primär-mjuk förklarar synligheten. Fast bottenknapp.

### 2d Chatt, mörkt läge (`app/chatt/[id].tsx`)
Toppfält: tillbaka, titel + "4 deltagare · idag 13.00", överlappande avatarstack (30 px, −10 marginal, 2 px yta-ring). Meddelandeflöde nedifrån och upp med gap 10; andras bubblor har avatar 26 till vänster. Inmatningsfält: pillformat i yta-alt med text-svag platshållare + 46 px skickaknapp i primär.

### 2e Profil (`app/(tabs)/profil.tsx`)
Display-rubrik + kugghjul 38. Avatar 76 med namn, ort, ★-betyg och antal betyg. Tre statistikkort i rad (tal i Unbounded 600 20; "Denna vecka" i accent). "INTERESSEN" som info-chips + streckad "+ Lägg till". "BFFS" med "Se alla"-textknapp och listgrupp: avatar 40, namn, "N aktiviteter ihop" i text-svag, BFF-pill i yta-alt.

### 2f Betygsätt (`app/betygsatt/[activityId].tsx`)
Toppfält "Senare" / titel. Display-fråga + förklaring att betygen är privata. Ett kort per deltagare: avatar 46 + namn + relation, femstjärnig rad (30 px, satta i stjärnfärg, tomma i `#DFD9CB`), avdelare, "Lägg till som BFF" med toggle. Bottenfält: primärknapp "Skicka betyg" + destruktiv textknapp "Anmäl någon".

## Ikoner
Emojin för aktiviteter är ersatt av ett eget linjeset. Path-datan ligger i **`friend-icons.js`** som `slug → d`.

- 24 × 24-rutnät, stroke **1,7**, `strokeLinecap`/`strokeLinejoin` = round, `fill="none"`
- Färgen kommer alltid utifrån. I vald chip: vit. I oval chip: `#56635C`. Mörkt läge: `#A7B4A9`. Aktiv flik: primär.
- Storlekar: **15** i chips, **18** i listrader och metarader, **22** i flikfältet
- Alla 30 slugs i `src/api/interests.ts` har en ikon, plus en ny: **`handarbete`** ("Handarbete" — sy, sticka, brodera och virka samlat som en aktivitet). Lägg till den i `INTERESTS`.
- `icon`-fältet (Ionicons-namnet) i `interests.ts` kan utgå — slugen räcker som nyckel, och `@expo/vector-icons` behövs inte längre för intressen.
- Ikonen renderas alltid som ett eget element bredvid texten, aldrig som ett tecken i strängen. Ingen emoji i aktivitetstaxonomin. (🎉 i chattens systemhändelse är innehåll, inte taxonomi, och får stå kvar.)

## Interaktion & beteende
Behåll befintliga flöden, navigering och datamodell. Inga nya interaktioner i denna leverans. Ändringar som ändå påverkar beteende:
- Fasta bottenfält på detalj-, skapa- och betygsskärmen (CTA ska inte kunna scrollas bort)
- "Lägg upp" i toppfältet på skapa-skärmen är avstängd till dess titel, tid och plats är satta
- Aktivt textfält markeras med primär kant

## State
Ingen ny state. Sätt ikon utifrån aktivitetens `interest`-slug och tema utifrån systemets färgschema (`useColorScheme`).

## Assets
Inga bildassets. Omslagsfoton och porträtt är användargenererade — i mockupen är de släppytor. Ikonsetet är vektordata i `friend-icons.js`, inga filer.

## Filer i paketet
- `FRIEND Designsystem.dc.html` — tokens och typografi, kort **1b** gäller
- `FRIEND Mockup.dc.html` — sex skärmar, 2a–2f
- `FRIEND Ikoner.dc.html` — ikonark med slugs och användning
- `friend-icons.js` — path-datan, redo att kopieras in i `mobile/src/`
- `ios-frame.jsx`, `image-slot.js`, `support.js` — enbart för att HTML-filerna ska öppna korrekt lokalt; ska inte in i appen

## Att göra i kodbasen, i ordning
1. Lägg till typsnitten och `useFonts` i root-layouten
2. Skriv om `src/theme.ts` med tokens ovan, ljust + mörkt
3. Kopiera in `friend-icons.js` och gör en `ActivityIcon`-komponent; lägg till `handarbete` i `INTERESTS` och plocka bort `icon`-fältet
4. Uppdatera primitiverna i `src/components/ui.tsx` (knapp, chip, kort, fält, listgrupp, toggle)
5. Styla om skärmarna i ordningen 2a → 2f
6. Flikfält sist, inklusive notisprick
